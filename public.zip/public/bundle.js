/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/script/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/script/AlarmUserHandler.js":
/*!****************************************!*\
  !*** ./src/script/AlarmUserHandler.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"default\", function() { return AlarmUserHandler; });\nfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError(\"Cannot call a class as a function\"); } }\n\nfunction _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if (\"value\" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }\n\nfunction _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }\n\n/* eslint-disable no-param-reassign */\nvar AlarmUserHandler =\n/*#__PURE__*/\nfunction () {\n  function AlarmUserHandler() {\n    _classCallCheck(this, AlarmUserHandler);\n  }\n\n  _createClass(AlarmUserHandler, null, [{\n    key: \"showHideAlarmContent\",\n    value: function showHideAlarmContent(_ref) {\n      var target = _ref.target;\n      var hideControl = AlarmUserHandler.getAncestorWithClass(target, 'hide-control');\n      if (!hideControl) return;\n      hideControl.show = !hideControl.show;\n      hideControl.setAttribute('data-show', // eslint-disable-next-line no-nested-ternary\n      hideControl.repeat ? hideControl.show ? 'max' : 'false' : hideControl.show ? 'true' : 'false');\n      var clockContainer = AlarmUserHandler.getAncestorWithClass(hideControl, 'clock-container');\n      if (!clockContainer) return;\n      clockContainer.setAttribute('data-show', hideControl.show ? 'true' : 'false');\n      var showDetails = AlarmUserHandler.getShowDetailsFromGrandParent(hideControl);\n      if (!showDetails) return;\n      showDetails.setAttribute('data-rotate', hideControl.show ? 'true' : 'false');\n    }\n  }, {\n    key: \"getAncestorWithClass\",\n    value: function getAncestorWithClass(descendent, className) {\n      if (!descendent || !descendent.tagName || !descendent.className || !descendent.parentElement) return null;\n\n      while (descendent.tagName.toLowerCase() !== 'body') {\n        if (descendent.className === className) {\n          return descendent;\n        }\n\n        descendent = descendent.parentElement;\n      }\n\n      return null;\n    }\n  }, {\n    key: \"getShowDetailsFromGrandParent\",\n    value: function getShowDetailsFromGrandParent(grandParent) {\n      var child = AlarmUserHandler.getChildWithClass(grandParent, 'hide-button');\n      if (!child) return null;\n      var grandChild = AlarmUserHandler.getChildWithClass(child, 'show-details');\n      return grandChild;\n    }\n  }, {\n    key: \"getChildWithClass\",\n    value: function getChildWithClass(parent, childClass) {\n      if (!parent || !parent.children) return null;\n      var children = parent.children;\n      var keys = Object.keys(children);\n\n      for (var i = 0; i < keys.length; i += 1) {\n        var className = children[keys[i]].className;\n\n        if (className === childClass || className && className.baseVal === childClass) {\n          return children[keys[i]];\n        }\n      }\n\n      return null;\n    }\n  }, {\n    key: \"onOffSwitch\",\n    value: function onOffSwitch(_ref2) {\n      var target = _ref2.target;\n      var onOffButton = target.className === 'on-off' ? target : AlarmUserHandler.getAncestorWithClass(target, 'on-off');\n      if (!onOffButton) return;\n      onOffButton.on = !onOffButton.on;\n      onOffButton.setAttribute('data-status', onOffButton.on ? 'on' : 'off');\n    }\n  }, {\n    key: \"deleteAlarm\",\n    value: function deleteAlarm(_ref3) {\n      var target = _ref3.target;\n      var alarm = AlarmUserHandler.getAncestorWithClass(target, 'clock-container');\n      if (!alarm) return;\n      /* eslint-disable-next-line no-alert */\n\n      if (window.confirm('Are you sure of deleting this clock?')) {\n        alarm.parentElement.removeChild(alarm);\n      }\n    }\n  }, {\n    key: \"updateClockName\",\n    value: function updateClockName(_ref4) {\n      var target = _ref4.target;\n      var hideControl = AlarmUserHandler.getAncestorWithClass(target, 'hide-control');\n      if (!hideControl) return;\n      var clockName = AlarmUserHandler.getClockNameFromAncestor(hideControl);\n      if (!clockName) return;\n      clockName.innerText = target.value;\n    }\n  }, {\n    key: \"getClockNameFromAncestor\",\n    value: function getClockNameFromAncestor(ancestor) {\n      var child = AlarmUserHandler.getChildWithClass(ancestor, 'hide-button');\n      if (!child) return null;\n      var grandChild = AlarmUserHandler.getChildWithClass(child, 'clock-name-minimized');\n      return grandChild;\n    }\n  }, {\n    key: \"handleRepeatSelection\",\n    value: function handleRepeatSelection(_ref5) {\n      var target = _ref5.target;\n      var hideControl = AlarmUserHandler.getAncestorWithClass(target, 'hide-control');\n      if (!hideControl) return;\n      hideControl.repeat = !hideControl.repeat;\n      hideControl.setAttribute('data-show', // eslint-disable-next-line no-nested-ternary\n      hideControl.repeat ? hideControl.show ? 'all' : 'false' : hideControl.show ? 'min' : 'false');\n    }\n  }, {\n    key: \"handleDaySelection\",\n    value: function handleDaySelection(_ref6) {\n      var target = _ref6.target;\n      if (!target) return;\n      target.selected = !target.selected;\n      target.setAttribute('data-selected', target.selected ? 'true' : 'false');\n    }\n  }]);\n\n  return AlarmUserHandler;\n}();\n\n\n\n//# sourceURL=webpack:///./src/script/AlarmUserHandler.js?");

/***/ }),

/***/ "./src/script/index.js":
/*!*****************************!*\
  !*** ./src/script/index.js ***!
  \*****************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _AlarmUserHandler__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AlarmUserHandler */ \"./src/script/AlarmUserHandler.js\");\n\nvar hideButtons = document.querySelectorAll('.clock-container .hide-button');\nhideButtons.forEach(function (button) {\n  return button.addEventListener('click', _AlarmUserHandler__WEBPACK_IMPORTED_MODULE_0__[\"default\"].showHideAlarmContent);\n});\nvar onOffSwitchs = document.querySelectorAll('.clock-container .on-off');\nonOffSwitchs.forEach(function (button) {\n  return button.addEventListener('click', _AlarmUserHandler__WEBPACK_IMPORTED_MODULE_0__[\"default\"].onOffSwitch);\n});\nvar deleteButtons = document.querySelectorAll('.clock-container .delete-field');\ndeleteButtons.forEach(function (button) {\n  return button.addEventListener('click', _AlarmUserHandler__WEBPACK_IMPORTED_MODULE_0__[\"default\"].deleteAlarm);\n});\nvar nameInputs = document.querySelectorAll('.clock-container .clock-name');\nnameInputs.forEach(function (inputs) {\n  return inputs.addEventListener('change', _AlarmUserHandler__WEBPACK_IMPORTED_MODULE_0__[\"default\"].updateClockName);\n});\nvar repeatButtons = document.querySelectorAll('.clock-container .repeat');\nrepeatButtons.forEach(function (button) {\n  return button.addEventListener('click', _AlarmUserHandler__WEBPACK_IMPORTED_MODULE_0__[\"default\"].handleRepeatSelection);\n});\nvar repeatDays = document.querySelectorAll('.clock-container .day');\nrepeatDays.forEach(function (day) {\n  return day.addEventListener('click', _AlarmUserHandler__WEBPACK_IMPORTED_MODULE_0__[\"default\"].handleDaySelection);\n});\n\n//# sourceURL=webpack:///./src/script/index.js?");

/***/ })

/******/ });